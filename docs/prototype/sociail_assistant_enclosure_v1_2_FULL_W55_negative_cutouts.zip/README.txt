Sociail Assistant – Bar Enclosure Prototype (v1.2 FULL) – PRINT READY via Negative Volumes
Generated: 2025-12-28T14:57:58

Locked spec
- Outer size: 150.0 x 55.0 x 22.0 mm
- Two-piece shell with alignment lip
- USB-C: LEFT end (-X)
- LED window: 75.0mm (medium), offset toward FRONT (+X) by 24.0mm
- Single button centered under LED
- Mic holes: front face (+X), upper
- Speaker holes: front face (+X), lower
- Snap tabs included (bottom) + screw bosses included (top+bottom)

Main parts
- sociail_assistant_bar_top_v1_2_W55.stl
- sociail_assistant_bar_bottom_v1_2_W55.stl

NEGATIVE VOLUMES (set as "Negative part" in Bambu Studio)
- neg_usb_c_left_end_v1_2.stl
- neg_led_window_offset_front_v1_2.stl
- neg_button_center_under_led_v1_2.stl
- neg_mic_holes_front_top_v1_2.stl
- neg_speaker_holes_front_lower_v1_2.stl
- neg_screw_holes_4x_v1_2.stl  (optional; apply to both parts)

Bambu Studio workflow
TOP:
1) Import sociail_assistant_bar_top_v1_2_W55.stl
2) Add Part -> Load... and load as NEGATIVE:
   - neg_led_window_offset_front_v1_2.stl
   - neg_button_center_under_led_v1_2.stl
   - (optional) neg_screw_holes_4x_v1_2.stl
BOTTOM:
1) Import sociail_assistant_bar_bottom_v1_2_W55.stl
2) Add Part -> Load... and load as NEGATIVE:
   - neg_usb_c_left_end_v1_2.stl
   - neg_mic_holes_front_top_v1_2.stl
   - neg_speaker_holes_front_lower_v1_2.stl
   - (optional) neg_screw_holes_4x_v1_2.stl

Recommended P1S settings (polish-first)
- Layer height: 0.08mm (hero) or 0.12mm (iterate)
- Walls: 4
- Top layers: 6
- Bottom layers: 6
- Infill: 12% gyroid
- Supports: NONE
- Seam: aligned (place seam on underside edge)
