Sociail Assistant v1.2 (Recreated)
Use Bambu Studio Negative Parts to subtract LED, button, and USB openings.
