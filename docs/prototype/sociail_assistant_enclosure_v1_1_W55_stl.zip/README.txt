Sociail Assistant – Bar Enclosure Prototype (v1.1)
Generated: 2025-12-28T03:06:55

What's new vs v1
- Width increased to 55.0 mm (battery/PCB-friendly)
- USB-C guide moved to END face (rear end at -X)
- Added snap-tab geometry on bottom (for v1.5 snap-fit experiments)
- Added screw boss cylinders (top/bottom) + drill-hole guides (for screw fallback)

Files
- sociail_assistant_bar_top_v1_1_W55.stl
- sociail_assistant_bar_bottom_v1_1_W55.stl
- sociail_assistant_feature_guides_v1_1_W55.stl (REFERENCE ONLY; NOT SUBTRACTED)

Dimensions (outer)
- Length: 150.0 mm
- Width:  55.0 mm
- Thickness: 22.0 mm
- Split plane: Z=11.0 mm

Wall/roof/floor thickness
- Walls: 2.6 mm
- Bottom floor: 2.6 mm
- Top roof: 2.6 mm

Print notes (Bambu P1S)
Top (hero)
- Print upside-down (roof on the bed)
- 0.12mm layers (0.08mm for hero)
- 4 walls, 6 top layers, 10–15% gyroid
Bottom
- Print upright (open cavity up)
- Same layers/settings

IMPORTANT
- This environment can't boolean-subtract openings, so the USB/LED/buttons/mic/speaker are provided as a separate "guides" STL.
  If you confirm exact placements, I can generate a STEP-style spec or help you do the cutouts in your CAD tool cleanly.

Next
- If you tell me where the LED bar should be (centered, offset, or near one end), I’ll lock its exact position.
- If you want screws now: tell me screw size preference (M2, M2.5, M3) and whether you want heat-set inserts.
