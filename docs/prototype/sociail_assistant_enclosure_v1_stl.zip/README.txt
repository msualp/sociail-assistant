Sociail Assistant – Bar Enclosure Prototype (v1)
Generated: 2025-12-28T03:02:59

Files
- sociail_assistant_bar_top_v1.stl
- sociail_assistant_bar_bottom_v1.stl
- sociail_assistant_feature_guides_v1.stl  (REFERENCE ONLY; NOT SUBTRACTED)

Dimensions (outer)
- Length: 150.0 mm
- Width:  45.0 mm
- Thickness: 22.0 mm
- Split plane: Z=11.0 mm
Wall/roof/floor thickness
- Walls: 2.6 mm
- Bottom floor: 2.6 mm
- Top roof: 2.6 mm
Alignment lip (top part)
- Height: 2.0 mm
- Thickness step-in: 1.2 mm

How to print on Bambu P1S (recommended)
Top (hero surface)
- Orientation: print "top" upside-down (roof on the bed) to get the cleanest outer surface after flip.
- Supports: NONE (designed to avoid internal overhangs)
- Layer height: 0.12 mm for iteration, 0.08 mm for hero print
- Walls/perimeters: 4
- Top surfaces: 6
- Infill: 10–15% gyroid
- Material: PLA+ for best surface; PETG for tougher; ASA later if needed.

Bottom
- Orientation: print upright (open cavity facing up)
- Supports: NONE
- Same layer height as top

Feature guides
- This STL is just a “marker” model to show where USB-C/LED/buttons/mic/speaker cutouts should go.
- If you want, I can generate a v1.1 with actual cutouts once you confirm exact port/button placement.

Next tweaks I can do immediately (no rework pain)
- Change width (W) to match your internal PCB/battery plan
- Move USB-C to side, center, or bottom
- Add screw bosses (M2/M2.5) and matching standoffs
- Add snap tabs + optional screw fallback
- Add rounded ends + nicer radii everywhere (more “consumer product” feel)
